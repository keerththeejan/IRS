<!--BLOCK#1 START DON'T CHANGE THE ORDER-->
<?php
$title ="Food Menu | SLGTI";
include_once ("Config.php");
include_once ("Head.php");
include_once ("Menu.php");
?>

<!--END DON'T CHANGE THE ORDER-->

<!--BLOCK#2 START YOUR CODE HEAR -->
<div class="row">
    <div class="col-12">
        <h1 class="h1">Food Menu</h1>
            <p> Foods very Testy and best quality.   </p>
    </div>
</div>

<div class="container">
    <div class="row" style="margin-top:3%;">
        <div class="col container">
            <div class="card" style="width:80%;Height:60% ;margin-top:3%;">
                <img class="card-img-top" src="img/123.png" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Monday</h5>
                    <a href="#" class="btn btn-primary">Click Here</a>
                </div>
            </div>
        </div>
        <div class="col container">
            <div class="card" style="width:80%;Height:60%;margin-top:3%;">
                <img class="card-img-top" src="img/154.png" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Tuesday</h5>
                    <a href="#" class="btn btn-primary">Click Here</a>
                </div>
            </div>
        </div>
        <div class="col container">
            <div class="card" style="width:80%;Height:60%;margin-top:3%;">
                <img class="card-img-top" src="img/564.png" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Wednesday</h5>
                    <a href="#" class="btn btn-primary">Click Here</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row" style="margin-top:3%;">
        <div class="col container">
            <div class="card" style="width:80%;Height:60%; margin-top:3%;">
                <img class="card-img-top" src="img/234.png" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Thursday</h5>
                    <a href="#" class="btn btn-primary">Click Here</a>
                </div>
            </div>
        </div>
        <div class="col container">
            <div class="card" style="width:80%;Height:60%; margin-top:3%;">
                <img class="card-img-top" src="img/789.png" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Friday</h5>
                    <a href="#" class="btn btn-primary">Click Here</a>
                </div>
            </div>
        </div>
        <div class="col container">
            <div class="card" style="width:80%;Height:60%;margin-top:3%;">
                <img class="card-img-top" src="img/987.png" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Saturday</h5>
                    <a href="#" class="btn btn-primary">Click Here</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row" style="margin-top:3%;">
        <div class="col container">
            <div class="card" style="width:80%;Height:60% ;margin-top:3%;">
                <img class="card-img-top" src="img/369.png" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Sunday</h5>
                    <a href="#" class="btn btn-primary">Click Here</a>
                </div>
            </div>
        </div>
        <div class="col container invisible">
            <div class="card" style="width:50%;Height:50% ;margin-top:3%;">
                <img class="card-img-top" src="img/New spl.png" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Tuesday</h5>
                    <a href="#" class="btn btn-primary">Click Here</a>
                </div>
            </div>
        </div>
        <div class="col container invisible">
            <div class="card" style="width:50%;Height:50%;margin-top:3%;">
                <img class="card-img-top" src="img/Thu spl.png" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Wednesday</h5>
                    <a href="#" class="btn btn-primary">Click Here</a>
                </div>
            </div>
        </div>
    </div>
</div>


    <!--END YOUR CODE-->

<!--BLOCK#3 START DON'T CHANGE THE ORDER-->
 <?php include_once ("Footer.php");  ?> 
 <!--END DON'T CHANGE THE ORDER-->