
<!--Block#1 start dont change the order-->
<?php 
$title="Home | SLGTI";    
include_once ("config.php");
include_once ("head.php");
include_once ("menu.php");


?>
<!-- end dont change the order-->


<!-- Block#2 start your code -->







<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Attendance System in PHP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
</head>
<body>

<div class="jumbotron-small text-center" style="margin-bottom:0">
  <h1>Student Attendance System</h1>
</div>






<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link" href="Attendance.php">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="session.php">Module</a>
  </li>

 
  <li class="nav-item">
    <a class="nav-link" href="MarkAttendance.php">Attendance</a>
  </li>
</ul>



    
  

<!-- end your code -->


<!--Block#3 start dont change the order-->
<?php include_once ("menu.php"); ?>  
<!--  end dont change the order-->
