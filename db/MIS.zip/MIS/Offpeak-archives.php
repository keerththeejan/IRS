<!-- BLOCK#1 START DON'T CHANGE THE ORDER-->
<?php
$title = "Home | SLGTI";
include_once("config.php");
include_once("head.php");
include_once("menu.php");
?>
<!--END DON'T CHANGE THE ORDER-->

<!--BLOCK#2 START YOUR CODE HERE -->


<br><br>

<div class="intro p-5 mb-5 border border-dark rounded" >
<div class="shadow p-3 mb-5 bg-white "> 
    <h4 class="display-4 text-center  "><i class="fas fa-folder-open"></i>  Off-Peak Request Archives</h4>
    </div>
    <div class="table-responsive-sm">
    <table class="table table-responsive-sm w-100">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name of applicant</th>
      <th scope="col">Registration No</th>
      <th scope="col">Department</th>
      <th scope="col">Date</th>
      <th scope="col">Time</th>
      <th scope="col">Warden's comment</th>
     <th colspan="3">Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>????</td>
      <td>????</td>
      <td>????</td>
      <td>?????</td>
      <td>?????</td>
      <td>?????</td>
      <td>?????</td>
     
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>????</td>
      <td>????</td>
      <td>????</td>
      <td>?????</td>
      <td>?????</td>
      <td>?????</td>
      <td>?????</td>
     
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>????</td>
      <td>????</td>
      <td>????</td>
      <td>?????</td>
      <td>?????</td>
      <td>?????</td>
      <td>?????</td>
      
    </tr>
    
    <tr>
      <th scope="row">3</th>
      <td>????</td>
      <td>????</td>
      <td>????</td>
      <td>?????</td>
      <td>?????</td>
      <td>?????</td>
      <td>?????</td>
      
    </tr>
    
  </tbody>
</table>
</div>

 
  </tbody>
</table>


    </div>
    <a href="Requestoffpeak.php"><<< Back to off-peak request </a>





<!--END OF YOUR COD-->

<!--BLOCK#3 START DON'T CHANGE THE ORDER-->
<?php include_once("footer.php"); ?>
<!--END DON'T CHANGE THE ORDER-->