<!--  bLOCK#1 start don't change the order-->
<?php 
$title =" Department Deatils| SLGTI";
include_once("config.php");
include_once("head.php");
include_once("menu.php");
?>
<!-- end don't change the order-->



<!-- bLOCK#2 start your code here & u can change -->
<br>
<hr>
<div class="alert bg-dark text-white text-center" role="alert"><h1>Add New Notice</h1>

</div>
<hr>
<div class="card-deck">
<br>
<br>
    <div class="card bg-dark text-white">
    <div class="card-header"><h1>Result</h1></div>
        <div class="card-body">
        <p class="card-text">
        <a href="NoticeAddResult.php">
        <h1>Add New Result<h1></a></p>
        </div>
    </div>
  
    <div class="card bg-dark text-white">
    <div class="card-header"><h1>Events</h1></div>
        <div class="card-body">
        <p class="card-text">
        <a href="NoticeEventUpload.php">
        <h1>Add New Events<h1></a></p>
        </div>
    </div>
    
    
    </div>
</div>
<hr>
   <!-- end your code here-->




<!--bLOCK#3  start don't change the order-->
    <?php include_once("footer.php");?>
<!-- end don't change the order-->
   