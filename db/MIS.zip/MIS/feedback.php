<!-- BLOCK#1 START DON'T CHANGE THE ORDER -->
<?php 
$title = "Chat | SLGTI" ;
include_once("config.php"); 
include_once("head.php"); 
include_once("menu.php");
include_once("homenav.php");
 ?>



Hello
 
<!-- END DON'T CHANGE THE ORDER -->
<!-- Sidebar -->
<div class="row">
<div class="col-4">

</div>




<div class="col-4">
</div>


<div class="col-4">
<ul class="nav nav-tabs">
<li class="nav-item">
    <a class="nav-link " href="home.php">Status</a>
  </li>
   <li class="nav-item">
    <a class="nav-link " href="single_chat.php">Chat</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="group_chat.php">Group chat</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="feedback.php">Feedback</a>
  </li>
  <li class="nav-item">
  <a class="nav-link" href="create_group.php">Create group</a>
  </li>
</ul>
</nav>





<div class="jumbotron p-3 mb-2 bg-dark text-light">
  <div class="container ">
    <h1 class="display-4 text-center"><h1 class="text-center">Send us your feed back!!</h1>
    <p class="lead text-center">Do you have a suggestion or found same bug?</p>
    <p class="lead text-center">let us know in the field bellow.</p>
  </div>
</div>
<p class="lead text-center">How was your experience?</p>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1"><h3><i class="far fa-smile"></i></h3></label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2"><h3><i class="far fa-grin-beam-sweat"></i></h3></label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2"><h3><i class="far fa-grin-squint-tears"></i></h3></label>



 

 





</div>
<div class="jumbotron p-3 mb-2 bg-white text-white">
<div class="container ">
  </div>
</div>

<textarea dir="auto" data-region="send-message-txt" class="form-control bg-white" rows="7" data-auto-rows="" data-min-rows="3" data-max-rows="5" role="textbox" aria-label="Describr your experience here..." placeholder="Describr your experience here..." style="resize: none"></textarea>
                    <button class="btn btn-link btn-icon icon-size-3 ml-1 mt-auto" aria-label="Send message" data-action="send-message">
                        <span data-region="send-icon-container">
                        <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw " title="Loading" aria-label="Loading"></i></span>
</span>
                    </button>

                    <button type="button" class="btn btn-dark btn-lg btn-block">Send a Feedback</button>

</div>





 <!-- /#sidebar-wrapper -->
 <!-- Page Content -->
 

 

 
                

                
                
                

<!-- END YOUR CODER HERE -->

    <!-- BLOCK#3 START DON'T CHANGE THE ORDER -->
    <?php include_once ("menu.php"); ?>   
    <!-- END DON'T CHANGE THE ORDER -->
