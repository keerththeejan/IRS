<!-- BLOCK#1 START DON'T CHANGE THE ORDER -->
<?php 
$title = "Chat | SLGTI" ;
include_once("config.php"); 
include_once("head.php"); 
include_once("menu.php");
 ?>
<!-- END DON'T CHANGE THE ORDER -->
<!-- Sidebar -->


<div class="col-3">
</div>



<div class="col-6">

</div>



<div class="col-3">
</div>




 <!-- /#sidebar-wrapper -->
 <!-- Page Content -->
 

 

 
                

                
                
                

<!-- END YOUR CODER HERE -->

    <!-- BLOCK#3 START DON'T CHANGE THE ORDER -->
    <?php include_once ("menu.php"); ?>  
    <!-- END DON'T CHANGE THE ORDER -->