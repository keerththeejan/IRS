		
<!--Block#1 start dont change the order-->
<?php 
$title="Add Course details | SLGTI";    
include_once ("config.php");
include_once ("head.php");
include_once ("menu.php");
?>
<!-- end dont change the order-->


<!-- Block#2 start your code -->

<!-- Heading  -->
<div class="row">
    <div class="col">
    <hr>
    </div>
    </div>

  <div class="row">
    <div class="col text-center">
    <h1>Students Assessments Results</h1>
    </div>
    </div>

    <div class="row ">
    <div class="col text-center">
    <h3 class="display-6">Department of Information & Communication Technology</h3>
    </div>
    </div>

   <div class="row">
    <div class="col">
    <hr color ="black" style="height:1px;">
    </div>
    </div> 
    <br>
    <br>

<!-- Heading end -->

<!-- Dropdown start -->

    <div class="row text-center ">
<div class="col">
    <div class="card" style="width: 15rem;">
  <div class="card-body">
    <h5 class="card-title">Assessment Name</h5>
    <h6 class="card-subtitle mb-2 text-muted">Poster</h6>
  </div>
</div>
</div>

<div class="col">
<div class="card" style="width: 15rem;">
  <div class="card-body">
    <h5 class="card-title">Assessment Date</h5>
    <h6 class="card-subtitle mb-2 text-muted">2017/05/03</h6>
  </div>
</div>
</div>


    <div class=col >
    <div class="card" style="width: 15rem;">
  <div class="card-body">
    <h5 class="card-title">Assessment Type</h5>
    <h6 class="card-subtitle mb-2 text-muted">Written</h6>
  </div>
</div>
</div>

    <div class=col>
    <div class="card" style="width: 15rem;">
  <div class="card-body">
    <h5 class="card-title">Students Attend </h5>
    <h6 class="card-subtitle mb-2 text-muted">30</h6>
  </div>
</div>
</div>
    </div>

    </div>
<br>
<br>

    <div class="row ">

    <div class="col">
    <table class="table text-center">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Students Name</th>
      <th scope="col">Students Marks </th>
      <th scope="col">Students Percentage</th>
      <th scope="col">Status</th>
          
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">A.Newsika</th>
      <td>20</td>
      <td>50%</td>
      <td> <span class="badge badge-success">Success</span></td>
    </tr>

    <tr>
      <th scope="row">A.Newsika</th>
      <td>20</td>
      <td>40%</td>
      <td><span class="badge badge-danger">Danger</span></td>
    </tr>
    
    <tr>
      <th scope="row">A.Newsika</th>
      <td>20</td>
      <td>40%</td>
      <td><span class="badge badge-warning">Warning</span></td>
    </tr>

  </tbody>
</table>
</div>
    </div>

    
<!-- Dropdown End -->

<!-- Assessments start -->
  

<!-- end your code -->
<!--Block#3 start dont change the order-->
<?php include_once ("footer.php"); ?>  
<!--  end dont change the order-->
    
    
  