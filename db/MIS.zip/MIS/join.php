<!-- BLOCK#1 START DON'T CHANGE THE ORDER -->
<?php 
$title = "Department Details | SLGTI" ;
include_once("config.php"); 
include_once("head.php"); 
include_once("menu.php");
 ?>
<!-- END DON'T CHANGE THE ORDER -->
<!-- Sidebar -->


<div class="jumbotron p-8 mb-2 bg-primary text-white ">
<h1 class="display-1 text-center"><i class="far fa-comments"></i> STUDENT MESSENGER</h1>
  <p class="text-center display-8 text-center">This is a student chating to share the informations. It using for the SLGTi students</p>
  <a class="btn btn-outline-light float-right" href="chat" role="button"  aria-disabled="true">getting start</a>
  <h1 class="display-1 text-center">
  <p class="text-center display-4 text-center">
  
  
</div>






 <!-- /#sidebar-wrapper -->
 <!-- Page Content -->
 
 

 

<!-- END YOUR CODER HERE -->

    <!-- BLOCK#3 START DON'T CHANGE THE ORDER -->
    <?php 
    include_once("footer.php");
    ?>
    <!-- END DON'T CHANGE THE ORDER -->