<!-- BLOCK#1 START DON'T CHANGE THE ORDER -->
<?php 
$title = "Department Details | SLGTI" ;
include_once("config.php"); 
include_once("head.php"); 
include_once("menu.php");
 ?>
<!-- END DON'T CHANGE THE ORDER -->
<!-- Sidebar -->




<div class ="row">

                <div class ="col-5  "><h5>Chat</h5>
                <textarea dir="auto" data-region="send-message-txt" class="form-control bg-white" rows="3" data-auto-rows="" data-min-rows="3" data-max-rows="7" role="textbox" aria-label="Write a message..." placeholder="Write a message..." style="resize: none"></textarea>
                            <button class="btn btn-link btn-icon icon-size-3 ml-1 mt-auto" aria-label="Send message" data-action="send-message">
                            <span data-region="send-icon-container"><i class="icon fa fa-paper-plane fa-fw " aria-hidden="true"></i></span>
                            <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw " title="Loading" aria-label="Loading"></i></span></span>
                            </button>

                
                
                 </div>
                <div class ="col-5 "><h5>User</h5> 

                <textarea dir="auto" data-region="send-message-txt" class="form-control bg-white" rows="3" data-auto-rows="" data-min-rows="3" data-max-rows="7" role="textbox" aria-label="Write a message..." placeholder="Write a message..." style="resize: none"></textarea>
                            <button class="btn btn-link btn-icon icon-size-3 ml-1 mt-auto" aria-label="Send message" data-action="send-message">
                            <span data-region="send-icon-container"><i class="icon fa fa-paper-plane fa-fw " aria-hidden="true"></i></span>
                            <span class="hidden" data-region="loading-icon-container"><span class="loading-icon icon-no-margin"><i class="icon fa fa-circle-o-notch fa-spin fa-fw " title="Loading" aria-label="Loading"></i></span></span>
                            </button>
</div>



                <div class ="col-2 p-3 p-3 mb-2 bg-dark text-white "><h5 class="text-center lg"  alt="50px"><i class="fas fa-users "></i></h5>
                <div class ="row">

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Gafoor Sahan</a>

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Abdullah</a>

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Faheem</a>

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Nifras</a>

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Kajan</a>

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Thilogini</a>

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Hanusiya</a>

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Janani</a>

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Jureesan</a>

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Sanjeevan</a>

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Keethijan</a>

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Sarujan</a>

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Mithusan</a>

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Thurgisan</a>

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Newsika</a>

                <a class="list-group-item list-group-item-action p-3 mb-2 bg-dark text-white" href=""> <i class="fas fa-user-circle"></i>
                Thuvarahan</a>

                </div>
                </div>   
                </div>
                </div>


</div>







 <!-- /#sidebar-wrapper -->
 <!-- Page Content -->
 

 

<!-- END YOUR CODER HERE -->

    <!-- BLOCK#3 START DON'T CHANGE THE ORDER -->
    <?php 
    include_once("footer.php");
    ?>
    <!-- END DON'T CHANGE THE ORDER -->