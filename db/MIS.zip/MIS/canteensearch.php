 
<!--block 1 start dont change the order-->

<?php 
$title="SEARCH CUSTOMER| SLGTI";
include_once("config.php");
include_once("head.php");
include_once("menu.php");
?>
  
    <!-- end dont change the order-->
<!--block 2 start my code here-->  


<div class="shadow p-3 mb-5 bg-white rounded">

        <div class="highlight-blue">
            <div class="container">
                <div class="intro">
                    <h1 class="display-3 text-center">QTY</h1>
                    
                 

                </div>
            </div>
        </div>
    </div>
    <form class="form-inline">
  
  
  <div class="form-group mx-sm-3 mb-2">
  <label for="inputPassword2" class="sr-only">Search</label>
   
<div class ="col">
<input type="search" class="form-control ds-input" id="search-input" placeholder="Search by order id" aria-label="Search for..." autocomplete="off" data-docs-version="4.3" spellcheck="false" 
role="combobox" aria-autocomplete="list" aria-expanded="false" aria-owns="algolia-autocomplete-listbox-0" dir="auto" style="position: relative; vertical-align: top;">
                  </div>
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit"><i class="fas fa-search"></i> </button>
    
    
    
    
    </div>

  

</form>

    <div class="mx-auto" >

<div class ="row">
<div class="col-7">
    <form  >
<div class="form-group p-3 mb-2 bg-light text-dark au_size  rounded">
<div class ="row">
  <div class ="col-3" >
    <p><h4>Order ID</h4></p>
  </div>
  <div class ="col-3" >
      <p><h4></h4></p>
  </div>
</div>
<div class ="row">
  <div class ="col-3" >
    <p><h4>User name</h4></p>
  </div>
  <div class ="col-3" >
      <p><h4></h4></p>
  </div>
</div>



<div class="row">

<div class="col-9">
 <table class="table table-borderless">
  <thead>
    <tr>
      <th scope="col">Item Name</th>
      <th scope="col">Item Qty</th>
      <th scope="col">Amount</th>
    
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"></th>
      <td></td>
      <td></td>
   
    </tr>
    <tr>
      <th scope="row"></th>
      <td></td>
      <td></td>
     
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="1"><h5><h5></td>
      <td ><h5><h5></td>
    </tr>
  </tbody>
</table>





</div>
</div>

 </div>
</form>
</div>
<div class="col-5">

<table class="table table-borderless">
  <thead>
    <tr>

      <th scope="col">Item name</th>
      <th scope="col">Item QTY</th>

    </tr>
  </thead>
  <tbody>
    <tr>

      <td>Mark</td>
      <td>Otto</td>
  
    </tr>
    <tr>
  
      <td>Jacob</td>
      <td>Thornton</td>
     
    </tr>
    <tr>
     
   <td>@twitter</td>
   <td>@gmail</td>
    </tr>
  </tbody>

</table>
<div class="col-8">
<button type="button" class="btn btn-primary btn-lg btn-block">Check</button>
</div>
</div>
</div>
</div>
  
<!--block 3 start dont change the order-->

    <?php include_once("footer.php"); ?>

    
    <!-- end dont change the order-->