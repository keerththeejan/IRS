<?php
    date_default_timezone_set("Asia/Colombo");
    echo $timestamp = date('d/m/y h:i:s A');
?>